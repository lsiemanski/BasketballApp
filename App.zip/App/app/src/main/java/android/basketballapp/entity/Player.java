package android.basketballapp.entity;

import android.basketballapp.converter.PositionConverter;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;
import androidx.room.TypeConverters;

@Entity(tableName="players")
public class Player {

    @PrimaryKey(autoGenerate = true)
    public int playerId;

    @NonNull
    @ColumnInfo(name = "name")
    public String name;

    @NonNull
    @ColumnInfo(name = "surname")
    public String surname;

    @TypeConverters(PositionConverter.class)
    @ColumnInfo(name = "position")
    public Position position;

    @ColumnInfo(name = "height")
    public int height;

    @ColumnInfo(name="image")
    public String image;

    public static Player EMPTY_PLAYER = new Player();

    @Ignore
    public Player() {}

    public Player(@NonNull String name, @NonNull String surname, @NonNull Position position, @NonNull int height) {
        this.name = name;
        this.surname = surname;
        this.position = position;
        this.height = height;
    }

    public enum Position {
        POINT_GUARD(1, "Point guard"),
        SHOOTING_GUARD(2, "Shooting guard"),
        SMALL_FORWARD(3, "Small forward"),
        POWER_FORWARD(4, "Power forward"),
        CENTER(5, "Center");

        private int code;
        private String description;

        Position(int code, String description) {
            this.code = code;
            this.description = description;
        }

        public int getCode() {
            return code;
        }

        public String getDescription() {
            return description;
        }
    }

    public int getPlayerId() {
        return playerId;
    }

    public String getName() {
        return name;
    }

    public String getSurname() {
        return surname;
    }

    public Position getPosition() { return position; }

    public int getHeight() {
        return height;
    }

    public String getImage() { return image; }
}
