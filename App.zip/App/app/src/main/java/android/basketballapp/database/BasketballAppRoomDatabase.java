package android.basketballapp.database;

import android.basketballapp.dao.PlayerDao;
import android.basketballapp.entity.Player;
import android.content.Context;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Database(entities = {Player.class}, version=1, exportSchema = false)
public abstract class BasketballAppRoomDatabase extends RoomDatabase {

    public abstract PlayerDao playerDao();

    private static volatile BasketballAppRoomDatabase INSTANCE;
    private static final int NUMBER_OF_THREADS = 4;
    public static final ExecutorService databaseWriterExecutor = Executors.newFixedThreadPool(NUMBER_OF_THREADS);

    public static BasketballAppRoomDatabase getDatabase(final Context context) {
        if(INSTANCE == null) {
            synchronized (BasketballAppRoomDatabase.class) {
                if(INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                                                    BasketballAppRoomDatabase.class,
                                             "basketball_app_database")
                            .addCallback(roomDatabaseCallback)
                            .build();
                }
            }
        }
        return INSTANCE;
    }

    private static RoomDatabase.Callback roomDatabaseCallback = new RoomDatabase.Callback() {
        @Override
        public void onOpen(@NonNull SupportSQLiteDatabase db) {
            super.onOpen(db);

            databaseWriterExecutor.execute(() -> {
                PlayerDao dao = INSTANCE.playerDao();
                dao.deleteAll();
                Player player = new Player("Michael", "Jordan", Player.Position.CENTER, 198);
                dao.insert(player);
                Player player2 = new Player("Kobe", "Bryant", Player.Position.SHOOTING_GUARD, 201);
                dao.insert(player2);
            });
        }
    };
}
