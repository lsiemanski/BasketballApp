package android.basketballapp.viewmodel;

import android.app.Application;
import android.basketballapp.entity.Player;
import android.basketballapp.repository.PlayerRepository;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;

public class PlayerViewModel extends AndroidViewModel {

    private PlayerRepository playerRepository;
    private LiveData<List<Player>> allPlayers;

    public PlayerViewModel(Application application) {
        super(application);
        playerRepository = new PlayerRepository(application);
        allPlayers = playerRepository.getAllPlayers();
    }

    public LiveData<List<Player>> getAllPlayers() {
        return allPlayers;
    }

    public void insert(Player player) {
        playerRepository.insert(player);
    }
}
